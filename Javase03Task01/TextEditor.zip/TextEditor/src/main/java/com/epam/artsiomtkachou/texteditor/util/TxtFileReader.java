package com.epam.artsiomtkachou.texteditor.util;

import java.io.*;
import java.util.ArrayList;

public class TxtFileReader {

    public static String readFileToString(String fileName) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
        String s;
        while((s=bufferedReader.readLine())!=null){
            stringBuilder.append(s);
            stringBuilder.append("\n");
        }
        return stringBuilder.toString();
    }
    
    public static ArrayList<String> readRegex(String fileName) throws IOException {
        ArrayList<String> arrayList = new ArrayList<String>();
        BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
        String s;
        while((s=bufferedReader.readLine())!=null){
            arrayList.add(s);
        }
        return  arrayList;
    }

}
