package creators;

import plane.Plane;

public abstract class AbstractBuilder{

		
		public abstract Plane getPlane(String name, int...args);
	
	
		
}
